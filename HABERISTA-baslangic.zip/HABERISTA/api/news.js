// Gerçek haber API/RSS bağlantısını sonraki aşamada ekleyeceğiz.
